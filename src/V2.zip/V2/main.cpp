#include <stdio.h>

extern "C" {
    void RunExample3();
}

int main(int argc, char* argv[])
{
    RunExample3();
    return 0;
}
